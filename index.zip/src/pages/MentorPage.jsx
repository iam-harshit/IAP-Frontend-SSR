import MentorHome from '@/Components/pages/Mentor-Page/MentorHome';

const MentorPage = () => {
  return (
    <div>
      <MentorHome />
    </div>
  );
};

export default MentorPage;
