
// import plus_icon from './plus_icon.png'
import plus_icon from '@/assets/ask-chatur/plus_icon.png'
import bulb_icon from '@/assets/ask-chatur/bulb_icon.png'
import compass_icon from '@/assets/ask-chatur/compass_icon.png'
// import user from '@/assets/ask-chatur/user.jpg'
import message_icon from '@/assets/ask-chatur/message_icon.png'
import code_icon from '@/assets/ask-chatur/code_icon.png'
import send_icon from '@/assets/ask-chatur/send_icon.png'

export const assets = {
  plus_icon,
  bulb_icon,
  compass_icon,
  message_icon,
  code_icon,
  send_icon,
  // user,
}
