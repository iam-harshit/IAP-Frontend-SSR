
const teamMembers = [
    {
      name: 'Ankit Kumar',
      role: 'Full Stack Developer',
      image: "https://api.cbss3.coolify.curiousecosystem.org/inspirationapp/MentorsProfile/ANKITCP.jpg",
    },
    {
      name: 'Rahul Mandal',
      role: 'Full Stack Developer',
      image: 'https://api.cbss3.coolify.curiousecosystem.org/inspirationapp/MentorsProfile/RahulCP.jpg',
    },
    {
      name: 'Harshit',
      role: 'Full Stack Developer',
      image: 'https://api.cbss3.coolify.curiousecosystem.org/inspirationapp/MentorsProfile/HarshitKumarCP.jpg',
    },
    {
      name: 'Naman',
      role: 'Full Stack Developer',
      image: 'https://api.cbss3.coolify.curiousecosystem.org/inspirationapp/MentorsProfile/NamanCP.jpg',
    },
    {
      name: 'Rohit Rambade',
      role: 'Full Stack Developer',
      image: 'https://api.cbss3.coolify.curiousecosystem.org/inspirationapp/MentorsProfile/Rohit_RambadeCP.jpg',
    },
  ];

export default teamMembers;