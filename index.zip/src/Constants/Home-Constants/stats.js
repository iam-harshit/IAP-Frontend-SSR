export const stats = [
  {
    number: 25000,
    title: 'Strong Community',
    description: 'Growing together with passion',
  },
  {
    number: 150,
    title: 'Expert Mentors',
    description: 'Experience that inspires growth',
  },
  {
    number: 300,
    title: 'Completed Events',
    description: 'Moments that built our story',
  },
  {
    number: 500,
    title: 'Positive Feedback',
    description: 'Customer satisfaction rate',
  },
];