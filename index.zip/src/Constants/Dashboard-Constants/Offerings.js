export const offeringsAvailable = [
      "1-1",
      "1-N",
      "chatSupport",
      "phoneCall",
      "directMessage",
      "webinar",
      "workshop",
      "resumeReview",
      "mockInterview",
      "digitalMaterials"
]



