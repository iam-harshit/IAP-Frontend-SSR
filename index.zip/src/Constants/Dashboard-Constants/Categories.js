export const categories = [
    { label: "technology", name: "technology" },
    { label: "business", name: "business" },
    { label: "spirituality", name: "spirituality" },
    { label: "well being", name: "well being" }
]

