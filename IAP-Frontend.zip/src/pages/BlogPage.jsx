import Blog from '@/Components/pages/blogs/BlogPage'


const BlogPage = () => {
  return (
    <div>
      <Blog/>
    </div>
  )
}

export default BlogPage