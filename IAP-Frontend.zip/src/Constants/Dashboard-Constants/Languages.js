export const LanguagesList = [
  'Hindi',
  'English',
  'Kannada',
  'Punjabi',
  'Tamil',
  'Telugu',
];
