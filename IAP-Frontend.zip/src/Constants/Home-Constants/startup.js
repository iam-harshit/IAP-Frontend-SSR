export const Feature_Cards = [
  {
    heading: `Connect With IAP Team`,
    para: 'Success Step 1',
    // para: `turning their bold startup <br /> dreams into tangible <br /> success stories.`,
  },
  {
    heading: `Skill up (Book Session)`,
    para: 'Success Step 2',
    // para: `to create plans that <br /> make a positive <br /> impact.`,
  },
  {
    heading: `Present your Pitch Deck`,
    para: 'Success Step 3',
    // para: `in developing solutions <br /> that solve real-world <br /> problems.`,
  },
  {
    heading: `Get Assistance`,
    para: 'Success Step 4',
    // para: `to create plans that <br /> make a positive <br /> impact.`,
  },
];

export const card_buttons = [
  {
    title: 'Join us now',
    link: 'https://wa.me/cbsecosystem',
  },
];
