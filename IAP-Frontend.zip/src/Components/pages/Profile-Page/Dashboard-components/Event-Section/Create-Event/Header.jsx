const HeaderSection = () => (
  <div className="relative px-6 sm:px-8 mb-4 lg:mb-0">
    <div  className="relative z-10" >
      <h1 className="text-h3 md:text-h3 lg:text-h2 text-customPurple font-semibold "> Create Your Event</h1>
    </div>
  </div>
);


export default HeaderSection
