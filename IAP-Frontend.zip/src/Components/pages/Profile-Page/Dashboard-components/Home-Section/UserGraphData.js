export const userData = [
  { month: 'Jan', users: 400 },
  { month: 'Feb', users: 500 },
  { month: 'Mar', users: 1600 },
  { month: 'Apr', users: 700 },
  { month: 'May', users: 1200 },
  { month: 'Jun', users: 900 },
  { month: 'Jul', users: 400 },
  { month: 'Aug', users: 500 },
  { month: 'Sep', users: 1200 },
  { month: 'Oct', users: 900 },
  { month: 'Nov', users: 700 },
  { month: 'Dec', users: 800 },
];
