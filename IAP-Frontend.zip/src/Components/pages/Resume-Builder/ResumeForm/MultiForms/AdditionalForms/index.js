export { default as SkillsForm } from '../SkillsForm.jsx';
export { default as LanguageForm } from './LanguageForm.jsx';
export { default as CustomForm } from './CustomForm.jsx';
export { default as ProjectsForm } from './ProjectsForm.jsx';
export { default as CertificatesForm } from './CertificatesForm.jsx';

// export { default as PersonalSkills } from './PersonalSkills.jsx';
