export default {
  meta: {
    Page: {
      env: { server: true, client: true },
    },
    Layout: {
      env: { server: true, client: true },
    },
  },
};
